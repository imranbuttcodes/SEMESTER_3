#include<iostream>
using namespace std;
void mySwap(int& a,int& b){
    int temp = a;
    a = b;
    b = temp;
}
int main(){
    int a = 20;
    int b = 10;
    cout<<"Before swap: "<<endl;
    cout<<"a: "<<a<<endl;
    cout<<"b: "<<b<<endl;
    mySwap(a,b);
    cout<<"After swap: "<<endl;
    cout<<"a: "<<a<<endl;
    cout<<"b: "<<b<<endl;
    return 0;
}