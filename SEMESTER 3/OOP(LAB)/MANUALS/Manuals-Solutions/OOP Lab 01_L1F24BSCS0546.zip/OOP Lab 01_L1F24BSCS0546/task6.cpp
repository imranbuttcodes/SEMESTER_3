#include<iostream>
#include<fstream>
using namespace std;
void mySwap(int& a,int& b){
    int temp = a;
    a = b;
    b = temp;
}
int strLength(const char* src){
    int len = 0;
    for(int i = 0; src[i] != '\0';i++){
        len++;
    }
    return len;
}
void strCopy(char* &dest, const char* src){
    cout<<strLength(src)<<endl;
    dest = new char[strLength(src)+1];
    for(int i = 0; i < strLength(src);i++){
        dest[i] = src[i];
    }
    dest[strLength(src)] = '\0';
}
void regrow(int* & arr,int& size,int input){
    int* new_arr = new int[size+ 1];
    for(int i = 0;i < size; i++){
        new_arr[i] = arr[i];
    } 
    new_arr[size] = input;
    size++;
    delete [] arr;
    arr = new_arr;
    
}
int findMax(const int* arr, int size){
    if(size == 0){
        return -1;
    }
    int maxNum = arr[0];
    for(int i = 0;i < size; i++){
        if(arr[i] > maxNum){
            maxNum = arr[i];
        }
    }
    return maxNum;
}
void readData(int* &evenArray,int* &oddArray,int& even_size,int& odd_size){
    ifstream read("data.txt");
    if(!read){
        cout<<"File doesn't exist!";
        return;
    }
    int garbage;
    while(read>>garbage){
        if (garbage == -1){
            return ;
        }
        if (garbage%2==0){
            regrow(evenArray,even_size,garbage);
        }else{
            regrow(oddArray,odd_size,garbage);
        }
    }

}
void writeData(const char* message,int num){
    ofstream write("output.txt",ios::app);
    if(!write){
        cout<<"file not found!";
        return;
    }
    write<<message<<num<<endl;
}
void evenOddSeperation(){
int* evenArray = nullptr;
    int* oddArray = nullptr;
    int evenSize = 0,oddSize = 0;
    readData(evenArray,oddArray,evenSize,oddSize);
    cout<<"Even Array: ";
    for(int i = 0;i < evenSize;i++){
        cout<<evenArray[i]<<" ";
    }
    cout<<endl;
    cout<<"Odd array: ";
    for(int i = 0;i < oddSize;i++){
        cout<<oddArray[i]<<" ";
    }
    cout<<endl;
    int even_max = findMax(evenArray,evenSize); 
    int odd_max = findMax(oddArray,oddSize);
    writeData("Max Even: ",even_max); 
    writeData("Max Odd: ",odd_max); 
    delete [] evenArray;
    delete [] oddArray;
}

void searhAndDelete(int* &arr,int& size,int element){
    int total_exist = 0;
    for(int i = 0;i < size; i++){
        if(arr[i] == element){
            total_exist++;
        }
    }
    if (total_exist == 0){
        return ;
    }
    int new_size = size-total_exist;
    int* new_arr = new int[new_size];
    for(int i = 0,j=0;i < size; i++){
        if(arr[i] != element){
            new_arr[j++] = arr[i];
        }
    }
    size = new_size;
    delete [] arr;
    arr = new_arr;

}
void choice5(){
        int* arr = nullptr;
        int garbage,size =0;
        cout<<"Enter elements (-1 to stop): ";
        while(true){
            cin>>garbage;
            if (garbage == -1){
                break;
            }
            regrow(arr,size,garbage);
        }
        int element;
            cout<<"Now enter element to remove: ";
            cin>>element;
            cout<<"Before removing "<<element<<endl;
            for(int i = 0;i < size;i++){
                cout<<arr[i]<<" ";
            }
            searhAndDelete(arr,size,element);
            cout<<"\nAfter removing "<<element<<endl;
            for(int i = 0;i < size;i++){
                cout<<arr[i]<<" ";
            }
            cout<<endl;
}
int main(){
    cout<<"------------ main menu -----------"<<endl;
    while(true){
    int choice ;
    cout<<"Press 1 for swap "<<endl;
    cout<<"Press 2 for strLength  "<<endl;
    cout<<"Press 3 for strCopy "<<endl;
    cout<<"Press 4 for EvenOddSeparation "<<endl;
    cout<<"Press 5 for searchAndDelete"<<endl;
    cout<<"Press 0 to exit "<<endl;
    cout<<"Enter your choice: ";
    cin>>choice;
    cin.ignore();
    if (choice == 0){
        cout<<"Exiting......."<<endl;
        return 0;
    }
    if(choice == 1){
        int a,b;
        cout<<"Enter two numbers: ";
        cin>>a>>b;
        cout<<"Before swaping: "<<endl;
        cout<<"a: "<<a<<endl;
        cout<<"b: "<<b<<endl;
        mySwap(a,b);
        cout<<"After swaping: "<<endl;
        cout<<"a: "<<a<<endl;
        cout<<"b: "<<b<<endl;

    }
    else if(choice == 2){
        char str [100];
        cout<<"Enter stirng: ";
        cin.getline(str,100);
        cout<<"Your string length: "<<strLength(str)<<endl; 

    }
    else if(choice == 3){
        char str [100];
        cout<<"Enter source string: ";
        cin.getline(str,100);
        char* dest = nullptr;
        strCopy(dest,str);
        cout<<"Source string: "<<str<<endl;
        cout<<"Destination string: "<<dest<<endl;
        delete [] dest;
    }else if(choice == 4){
        evenOddSeperation();
    }
    else if(choice == 5){
        choice5();
    }else{
        cout<<"Invalid input!";
    }
    }
    return 0;
}