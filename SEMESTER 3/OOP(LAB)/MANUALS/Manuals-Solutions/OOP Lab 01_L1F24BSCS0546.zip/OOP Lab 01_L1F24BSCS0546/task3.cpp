#include<iostream>
using namespace std;
int strLength(const char* src){
    int len = 0;
    for(int i = 0; src[i] != '\0';i++){
        len++;
    }
    return len;
}
void strCopy(char* &dest, const char* src){
    cout<<strLength(src)<<endl;
    dest = new char[strLength(src)+1];
    for(int i = 0; i < strLength(src);i++){
        dest[i] = src[i];
    }
    dest[strLength(src)] = '\0';
}
int main()
{
     const char* source = "Hello";
    char* destination = nullptr;

    strCopy(destination, source);

    cout << "Source: " << source << endl;
    cout << "Destination: " << destination << endl;

    delete[] destination; 
    return 0;
}
