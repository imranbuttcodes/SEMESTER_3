#include<iostream>
#include<fstream>
using namespace std;
void regrow(int* & arr,int& size,int input){
    int* new_arr = new int[size+ 1];
    for(int i = 0;i < size; i++){
        new_arr[i] = arr[i];
    } 
    new_arr[size] = input;
    size++;
    delete [] arr;
    arr = new_arr;
    
}
int findMax(const int* arr, int size){
    if(size == 0){
        return -1;
    }
    int maxNum = arr[0];
    for(int i = 0;i < size; i++){
        if(arr[i] > maxNum){
            maxNum = arr[i];
        }
    }
    return maxNum;
}
void readData(int* &evenArray,int* &oddArray,int& even_size,int& odd_size){
    ifstream read("data.txt");
    if(!read){
        cout<<"File doesn't exist!";
        return;
    }
    int garbage;
    while(read>>garbage){
        if (garbage == -1){
            return ;
        }
        if (garbage%2==0){
            regrow(evenArray,even_size,garbage);
        }else{
            regrow(oddArray,odd_size,garbage);
        }
    }

}
void writeData(const char* message,int num){
    ofstream write("output.txt",ios::app);
    if(!write){
        cout<<"file not found!";
        return;
    }
    write<<message<<num<<endl;
}
int main(){
    int* evenArray = nullptr;
    int* oddArray = nullptr;
    int evenSize = 0,oddSize = 0;
    readData(evenArray,oddArray,evenSize,oddSize);
    cout<<"Even Array: ";
    for(int i = 0;i < evenSize;i++){
        cout<<evenArray[i]<<" ";
    }
    cout<<endl;
    cout<<"Odd array: ";
    for(int i = 0;i < oddSize;i++){
        cout<<oddArray[i]<<" ";
    }
    cout<<endl;
    int even_max = findMax(evenArray,evenSize); 
    int odd_max = findMax(oddArray,oddSize);
    writeData("Max Even: ",even_max); 
    writeData("Max Odd: ",odd_max); 
    delete [] evenArray;
    delete [] oddArray;
    return 0;
}