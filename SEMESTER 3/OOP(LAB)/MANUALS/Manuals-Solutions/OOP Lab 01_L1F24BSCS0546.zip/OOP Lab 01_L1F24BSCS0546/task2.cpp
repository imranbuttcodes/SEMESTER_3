#include<iostream>
using namespace std;
int strLength(const char* src){
    int len = 0;
    for(int i = 0; src[i] != '\0';i++){
        len++;
    }
    return len;
}
main()
{
    char* src = new char[10]{'1','2','3','b','6','4','s','t','y','u'};
    cout<<"Len: "<<strLength(src)<<endl;
    delete[] src;
    return 0;
}
