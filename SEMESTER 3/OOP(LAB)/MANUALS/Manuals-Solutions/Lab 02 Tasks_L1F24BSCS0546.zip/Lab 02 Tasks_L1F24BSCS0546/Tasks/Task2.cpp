//#include<iostream>
//using namespace std;
//int Area(int length) {
//	return (length * length);
//}
//double Area(int length, int width) {
//	return (length * width) / 2;
//}
//double Area(double radius) {
//	return	3.14*(radius * radius);
//}
//int main() {
//	cout << "Area of square(side: 4): " << Area(4)<<endl;
//	cout << "Area of Triangle(base: 4, height 5): " << Area(4, 5) << endl;
//	cout << "Area of Circle(radius: 3.5): " << Area(3.5) << endl;
//	return 0;
//}