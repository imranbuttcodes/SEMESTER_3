#include<iostream>
using namespace std;
#include<iostream>
using namespace std;
double average(int a, int b) {
	return (a + b) / 2;
}
double average(double a, double b) {
	return (a + b) / 2;
}
int Area(int length) {
	return (length * length);
}
double Area(int length, int width) {
	return (length * width) / 2;
}
double Area(double radius) {
	return	3.14*(radius * radius);
}


void Task1(){
	cout << "Average of two numbers(4,7): " << average(4, 7) << endl;
	cout << "Average of two numbers(5.8,6.7): " << average(5.8, 6.7) << endl;
}
void Task2(){
	cout << "Area of square(side: 4): " << Area(4)<<endl;
	cout << "Area of Triangle(base: 4, height 5): " << Area(4, 5) << endl;
	cout << "Area of Circle(radius: 3.5): " << Area(3.5) << endl;

}

class Rectangle {
	double length, width;
public:
	void setValue(double len, double wid) {
		length = len;
		width = wid;
	}
	void display() {
		cout << "Length: " << length << endl;
		cout << "Width: " << width << endl;
	}
	double calculateArea() {
		return (length * width);
	}

};
void Task3() {
	Rectangle r1;
	r1.setValue(45.4, 34.6);
	r1.display();
	cout << "Calculated Area: " << r1.calculateArea() << endl;
}
void regrowChar(char*& arr, int& size,char input) {
	char* new_arr = new char[size + 1];
	for(int i = 0;i < size; i++){
		new_arr[i] = arr[i];
	}
	new_arr[size] = input;
	size++;
	delete[] arr;
	arr = new_arr;
}

class Student {
private:
	char* studentName = nullptr;
	int studentID;
	double GPA;
	char* degreeName = nullptr;
	int st_size = 0, degree_size = 0;
public:
	void setValue(char* name,int ID,double gpa,char* degree,int stSize,int degreeSize) {
		st_size = stSize, degree_size = degreeSize;

		studentName = name;
		degreeName = degree;
		studentID = ID;
		GPA = gpa;
	}
	void display(int total,int obtanedMarks) {
		cout << "------- " << studentName << " Info -------\n";
		cout << "Name: " << studentName << endl;
		cout << "StudentID: " << studentID << endl;
		cout << "GPA: " << GPA << endl;
		cout << "Deegree Name: " << degreeName << endl;
		cout << "Percentage Obtained: " << Student::calculatePercentage(total, obtanedMarks) << "%" << endl;
		cout << "Grade: " << AssignGrade(Student::calculatePercentage(total, obtanedMarks)) << endl;
	}
	double calculatePercentage(double total, double obtained) {
		return (obtained / total) * 100.0;
	}
	char AssignGrade(double percentage) {
		if (percentage >= 86 && percentage <= 100) {
			return 'A';
		}
		else if (percentage >= 70 && percentage < 86) {
			return 'B';
		}
		else if (percentage >= 50 && percentage < 70) {
			return 'C';
		}
		else if (percentage >= 30 && percentage < 50) {
			return 'D';
		}
		else {
			return 'F';
		}
	}
	~Student(){
		delete[] studentName;
		delete[] degreeName;
	}
};

void getInput(char*& arr, int& size) {
	char garbage;
	while (true) {
		cin.get(garbage);
		if (garbage == '\n')   break;
		regrowChar(arr, size, garbage);
	}
	regrowChar(arr, size, '\0');
}
void recievingInputs(char*& name, char*& degree, int& ID, double& GPA,int& degreeSize,int& Stsize,int& obtainedMarks) {
	cout << "Enter Name: ";
	getInput(name, Stsize);
	cout << "Enter your StudentID: ";
	cin >> ID;
	cout << "Enter your GPA: ";
	cin >> GPA;
	cin.ignore();
	cout << "Enter your degreeName: ";
	getInput(degree, degreeSize);
	cout << "Obtained Marks: ";
	cin >> obtainedMarks;
	cin.ignore();
}
void Task4() {
    cout<<"----------- Welcome to Student Portal ------------\n";
	Student s1,s2,s3;
	char* s1Name = nullptr;
	char* s1Deegree = nullptr;
	int s1_Stsize = 0,s1_degreeSize = 0;
	char* s2Name = nullptr;
	char* s2Deegree = nullptr;
	int s2_Stsize = 0,s2_degreeSize = 0;
	
	char* s3Name = nullptr;
	char* s3Deegree = nullptr;
	int s3_Stsize = 0,s3_degreeSize = 0;
	
	
	
	int total = 100,s1_ObtainedMarks,s2_ObtainedMarks,s3_ObtainedMarks;
	int ID;
	double GPA;
	recievingInputs(s1Name, s1Deegree, ID, GPA, s1_degreeSize, s1_Stsize,s1_ObtainedMarks);
	s1.setValue(s1Name, ID, GPA, s1Deegree, s1_Stsize, s1_degreeSize);
	s1.display(total,s1_ObtainedMarks);
	
	recievingInputs(s2Name, s2Deegree, ID, GPA, s2_degreeSize, s2_Stsize,s2_ObtainedMarks);
	s2.setValue(s2Name, ID, GPA, s2Deegree, s2_Stsize, s2_degreeSize);
	s2.display(total,s2_ObtainedMarks);
	
	recievingInputs(s3Name, s3Deegree, ID, GPA, s3_degreeSize, s3_Stsize,s3_ObtainedMarks);
	s3.setValue(s3Name, ID, GPA, s3Deegree, s3_Stsize, s3_degreeSize);
	s3.display(total,s3_ObtainedMarks);
	delete[] s1Name;
	delete[] s1Deegree;
	delete[] s2Name;
	delete[] s2Deegree;
	delete[] s3Name;
	delete[] s3Deegree;
	cout<<"Enter any key to exit...";
	cin.get();
}

int main(){
   cout<<"------ Welcome to the menu -------\n";
   char ch;
   while(true){
    cout<<"Press 1 for Overloaded Average Function"<<endl;
    cout<<"Press 2 for Overloaded Area Function "<<endl;
    cout<<"Press 3 for Testing Rectangle class."<<endl;
    cout<<"Press 4 for Student Portal "<<endl;
    cout<<"Press 0 for exit."<<endl;
    cout<<"Enter your choice: " ;
    cin>>ch;
    cin.ignore();
    if(ch == '1'){
        Task1();
    }else if(ch == '2'){
        Task2();
    }else if(ch == '3'){
        Task3();
    }else if(ch == '4'){
        Task4();
    }else if(ch == '0'){
        cout<<"Exiting ......."<<endl;
        return 0;
    }else{
        cout<<"Invalid Input!"<<endl;
    }
   }
    return 0;
}