//#include<iostream>
//using namespace std;
//
//class Rectangle {
//	double length, width;
//public:
//	void setValue(double len, double wid) {
//		length = len;
//		width = wid;
//	}
//	void display() {
//		cout << "Length: " << length << endl;
//		cout << "Width: " << width << endl;
//	}
//	double calculateArea() {
//		return (length * width);
//	}
//
//};
//int main() {
//	Rectangle r1;
//	r1.setValue(45.4, 34.6);
//	r1.display();
//	cout << "Calculated Area: " << r1.calculateArea() << endl;
//	return 0;
//}