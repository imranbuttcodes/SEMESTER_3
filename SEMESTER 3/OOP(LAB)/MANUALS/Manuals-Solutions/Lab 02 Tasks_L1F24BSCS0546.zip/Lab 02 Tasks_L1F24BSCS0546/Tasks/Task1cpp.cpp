#include<iostream>
using namespace std;
double average(int a, int b) {
	return (a + b) / 2;
}
double average(double a, double b) {
	return (a + b) / 2;
}
int main() {
	
	cout << "Average of two numbers(4,7): " << average(4, 7) << endl;
	cout << "Average of two numbers(5.8,6.7): " << average(5.8, 6.7) << endl;
	
	return 0;
}