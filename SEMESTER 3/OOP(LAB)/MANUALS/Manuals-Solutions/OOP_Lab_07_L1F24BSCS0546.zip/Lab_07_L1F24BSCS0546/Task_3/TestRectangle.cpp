#include <iostream>
#include "Rectangle.h"
using namespace std;

int main() {    
    cout<<"Creating obj...\n\n";
    Rectangle r1;
    cout<<"Accepting input through (>>)....\n\n";
    cin>>r1;
    cout<<"Printing through (<<).....\n\n";
    cout<<r1;
    
    return 0;
}