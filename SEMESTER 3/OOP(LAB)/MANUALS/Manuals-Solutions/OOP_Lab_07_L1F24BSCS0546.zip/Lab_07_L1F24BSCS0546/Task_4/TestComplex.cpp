#include <iostream>
#include "Complex.h"
using namespace std;

int main() {
    cout<<"Creating obj...\n\n";
    Complex c1;
    cout<<"Accepting input through (>>)....\n\n";
    cin>>c1;
    cout<<"Printing through (<<).....\n\n";
    cout<<c1;
    
    return 0;
}