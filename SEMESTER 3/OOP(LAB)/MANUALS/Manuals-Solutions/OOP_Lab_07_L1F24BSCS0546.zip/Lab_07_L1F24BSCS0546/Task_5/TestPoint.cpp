#include <iostream>
#include "Point.h"
using namespace std;

int main() {
    cout<<"Creating obj...\n\n";
    Point p1;
    cout<<"Accepting input through (>>)....\n\n";
    cin>>p1;
    cout<<"Printing through (<<).....\n\n";
    cout<<p1;
    
    return 0;
}