// #include <iostream>
// using namespace std;
// char to_upper(char a){
//     if(a >= 65 && a <= 90)   return a;
//     a-= 32;
//     return a;
// }
// char to_lower(char ch){
//     if(ch >=97 && ch <= 122)   return ch;
//     else if(ch >= 65 && ch <= 90)   return (ch+=32);
//     cout<<"Invalid value entered!!!!"<<endl;
//     return '\0';
// }
// class Name{
// private:
// char* firstname;
// char* lastname;
// public:
//     Name(char* firstname = nullptr, char* lastname = nullptr) // Parameterized constructor with default values
//     {
//         if(firstname){
        
//         this->firstname = new char[strLen(firstname) + 1];
//         for(int i = 0;firstname[i]!='\0'; i++){
//             this->firstname[i] = firstname[i];
//         } 
        
//     }
//         if(lastname){
//         for(int i = 0;lastname[i]!='\0'; i++){
//            this->lastname[i] = lastname[i];
//         } 
//         }
//     }
//     int strLen(const char* arr){
//         int len = 0;
//         for(int i = 0;arr[i] != '\0';i++) {
//             len++;
//         }
//         return len;
//     }
//     char* getFirstName() {
//         return firstname;
//     }
//     char* getLastName() {
//         return lastname;
//     }
    
// };
// //  int strLen(const char* arr){
// //         int len = 0;
// //         for(int i = 0;arr[i] != '\0';i++) {
// //             len++;
// //         }
// //         return len;
// //     }
// void setName(const char* name){
//     for(int i =0; name[i]!= '\0'; i++){
//         cout<<name[i]<<" ";
//     }
//     cout<<endl;
//     char* new_Name = (char*)name;
//     for(int i = 0;name[i] != '\0'; i++){
//         cout<<new_Name[i]<<" ";
//     }
//     cout<<endl;
//     cout<<new_Name<<endl;
// }
// int main() {
// //   const char* name = (const char*)"Imran Butt";
// //   if(name){
// //     cout<<"True"<<endl;
// //   }else{
// //     cout<<"False"<<endl;
// //   }
//     // Name name((char*)"Imran",(char*)"Butt");
//     // cout<<name.getFirstName()<<endl;
//     // cout<<name.getLastName()<<endl;
//     char* data = new char[1];
//     data[0] = '\0';
//     if(data){
//         cout<<"True"<<endl;
//     }else{
//         cout<<"False\n";
//     }
//     int len = 0;
//     for(int i = 0; data[i] != '\0'; i++){
//         len++;
//     }
//     cout<<len<<endl;
//     //setName("Imran Butt");
//     return 0;
// }

#include<iostream>
using namespace std;
int main() {
// 	int** data = new int* [4];
// 	for (int i = 0; i < 4; i++) {
// 		data[i] = new int[3];
// 	}
// 	for (int i = 0; i < 4; i++) {
// 		for (int j = 0; j < 3; j++) {
// 			if (!(cin >> data[i][j])) {
// 			    cout<<"Invalid"<<endl;
// 				return false;
// 			}
// 		}
// 		for (int i = 0; i < 4; i++) {
// 			for (int j = 0; j < 3; j++) {
// 				cout << data[i][j] << " ";
// 			}
// 			cout << endl;
// 		}
// 	}
int mat[2][3] = {{1,2,3},{4,5,6}};
int mat2[3][2] = {
    {10,11},
    {20,21},
    {30,31},
};
int mat3[2][2];//row of first mat and col of second mat
for(int i = 0; i < 2; i++){
    for(int j = 0;j < 2;j++){
        int var =0;
        for(int k = 0; k < 3; k++){
            var+=mat[i][k]*mat2[k][j];
        }
        mat3[i][j] = var;
    }
}
for(int i = 0; i < 2; i++){
    for(int j = 0;j < 2; j++){
        cout<<mat3[i][j]<<" ";
    }
    cout<<endl;
}
}