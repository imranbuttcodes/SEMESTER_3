#include<iostream>
#include "Matrix.h"
using namespace std;

Matrix::Matrix():rows(0),cols(0) {
	allocateMatrix();
}

Matrix::Matrix(int rows, int cols):cols(cols),rows(rows) {
    allocateMatrix();
}
Matrix::Matrix(const Matrix& other):rows(other.rows),cols(other.cols) {
	
	data = new int* [rows];
	for (int i = 0; i < rows; i++) {
		data[i] = new int[cols];
	}
	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < cols; j++) {
			data[i][j] = other.data[i][j];
		}
	}


}
bool Matrix::inputMatrix() 
{
	cout << "Input " << rows * cols << "Elements: ";
	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < cols; j++) {
			cin >> data[i][j];
		}
	}

	return true;

}
void Matrix::setElement(int r, int c, int value) {
	if (!isValidIndex(r, c)) {
		cout << "Invalid rows or columns enterd!";
		return;
	}
	data[r][c] = value;
}
int Matrix::getElement(int r, int c) {
	if (!isValidIndex(r,c)) {
		cout << "Invalid rows or columns enterd!";
		return 0;
	}
	return data[r][c];
}
void Matrix::displayMatrix() {
	cout << "Matrix:\n";
	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < cols; j++) {
			cout << data[i][j] << " ";
		}
		cout << endl;
	}
}
bool Matrix::isValidIndex(int r, int c) {
	if (r < 0 || r > rows || c < 0 || c > cols) {
		return false;
	}
	return true;
}
bool Matrix::addMatrix(const Matrix& other) {
	if (!(other.rows == rows && other.cols == cols)) {
		cout << "Can't add the matrix due to mismatch size\n";
		return false;
	}
	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < cols; j++) {
			data[i][j] += other.data[i][j];

		}
	}
	return true;
}
bool Matrix::subtractMatrix(const Matrix& other) {
	if (!(other.rows == rows && other.cols == cols)) {
		cout << "Can't subtract the matrix due to mismatch size\n";
		return false;
	}
	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < cols; j++) {
			data[i][j] -= other.data[i][j];

		}
	}
	return true;
}
bool Matrix::multiplyMatrix(const Matrix& other){
    if(cols != other.rows){
        cout<<"Invlaid dimension can't be multiplied!"<<endl;
        return false;
    }
    int** temp_data = new int*[rows];
    for(int i = 0; i< rows; i++){
        temp_data[i] = new int[other.cols];
    }
    for(int i = 0;i < rows; i++){
        for(int j = 0; j < other.cols; j++){
            int sum = 0;
            for(int k = 0; k < cols; k++){
                sum += data[i][k]*other.data[k][j]; 
            }
            temp_data[i][j] = sum;
        }
    }
    cout<<"Resultant martrix\n";
    for(int i = 0;i < rows; i++){
        for(int j = 0; j < other.cols; j++){
            cout<<temp_data[i][j]<<" ";
        }
        cout<<endl;
    }
    return true;
}

void Matrix::transpose(){
    cout<<"Transpose\n";
    for(int i = 0; i < cols; i++){
        for(int j = 0; j < rows; j++){
            cout<<data[j][i]<<" ";
        }
        cout<<endl;
    }
}
bool Matrix::isEqual(const Matrix& other){
    if(rows != other.rows || cols != other.cols)     return false;
    for(int i = 0; i < rows; i++){
        for(int j = 0 ; j < cols; j++){
            if(data[i][j] != other.data[i][j]){
                return false;
            }
        }
    }
    return true;
}
int Matrix::getRows(){
    return rows;
}
int Matrix::getCols(){
    return cols;
}
void Matrix::allocateMatrix(){
    data = new int*[rows];
    for(int i = 0;i < rows; i++){
        data[i] = new int[cols];
    }
}
void Matrix::clear(){
    for(int i = 0 ;i < rows; i++){
        delete[] data[i];
    }
    delete[] data;
}
void Matrix::fillRandom(){
    for(int i = 0; i < rows; i++){
        for(int j = 0; j < cols; j++){
            data[i][j] = ((i*j) + (3*j));
        }
    }
}

void Matrix::copyFrom(const Matrix& other){
    if(rows != other.rows || cols != other.cols){
        cout<<"Can't be copied due to dimensions mismatch!"<<endl;
        return;
    }
    for(int i = 0; i< rows; i++){
        for(int j = 0; j < cols; j++){
            data[i][j] = other.data[i][j];
        }
    }   
}
