x = 0.1 + 0.2
if x == 0.3:
    print("Yes")
else:
    print("No")